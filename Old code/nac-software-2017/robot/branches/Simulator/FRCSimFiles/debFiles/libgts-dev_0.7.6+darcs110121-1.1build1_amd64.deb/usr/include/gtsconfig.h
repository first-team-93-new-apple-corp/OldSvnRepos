/* gtsconfig.h
 *
 * This is a generated file.  Please modify `configure.in'
 */

#ifndef GTSCONFIG_H
#define GTSCONFIG_H


#define GTS_MAJOR_VERSION 0
#define GTS_MINOR_VERSION 7
#define GTS_MICRO_VERSION 6

#endif /* GTSCONFIG_H */
